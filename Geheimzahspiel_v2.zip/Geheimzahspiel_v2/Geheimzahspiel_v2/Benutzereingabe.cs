﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geheimzahspiel_v2
{
    using System;

    class BenutzerEingabe
    {
        public static int EingabeLesen()
        {
            int eingabe;
            while (!int.TryParse(Console.ReadLine(), out eingabe))
            {
                Console.WriteLine("Ungültige Eingabe. Bitte geben Sie eine Zahl ein.");
            }
            return eingabe;
        }
    }

}
