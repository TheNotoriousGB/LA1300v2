﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geheimzahspiel_v2
{
    class Spiel
    {
        private string benutzername;
        private int zufallszahl;

        public void Start()
        {
            Console.WriteLine("Geben Sie einen Benutzernamen ein.");
            benutzername = Console.ReadLine();

            ZufallszahlGenerator zufallszahlGenerator = new ZufallszahlGenerator();
            zufallszahl = zufallszahlGenerator.Zufallszahl(1, 100);

            SpielRunde();
        }

        private void SpielRunde()
        {
            int versuche = 0;

            do
            {
                Console.WriteLine("Geben Sie eine Zahl zwischen 1-100 ein");
                int eingebeneZahl = BenutzerEingabe.EingabeLesen();

                if (eingebeneZahl < 1 || eingebeneZahl > 100)
                {
                    Console.WriteLine("Ungültige Eingabe: Bitte geben Sie eine Zahl von 1-100");
                    continue;
                }

                versuche++;

                if (eingebeneZahl > zufallszahl)
                {
                    Console.WriteLine("Die Zahl ist zu groß.");
                }
                else if (eingebeneZahl < zufallszahl)
                {
                    Console.WriteLine("Die Zahl ist zu niedrig.");
                }
                else
                {
                    Console.WriteLine($"Die Zahl {eingebeneZahl} ist die richtige Zahl.");
                    Console.WriteLine($"Glückwunsch! Du hast nur {versuche} Versuche gebraucht.");

                    Highscore highscore = new Highscore();
                    highscore.VersuchHinzufügen(benutzername, versuche);

                    Console.WriteLine("Willst du weiter spielen [y/n]");
                    char antwort = Console.ReadKey().KeyChar;

                    if (antwort == 'y' || antwort == 'Y')
                    {
                        Console.Clear();
                        Start();
                    }
                    else
                    {
                        highscore.WriteHighscore();
                        Console.WriteLine("Schließen Sie das Fenster.");
                        Environment.Exit(0);
                    }
                }

            } while (true);
        }
    }
}
