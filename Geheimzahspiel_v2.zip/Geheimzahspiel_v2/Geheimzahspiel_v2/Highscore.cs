﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geheimzahspiel_v2
{
    class Highscore
    {
        private string pfad = @"C:\Users\gabri\OneDrive\Dokumente\Highscore.txt";

        public void VersuchHinzufügen(string benutzername, int versuche)
        {
            string inhalt = $"{benutzername}: {versuche}";
            File.WriteAllText(pfad, inhalt);
        }

        public void WriteHighscore()
        {
            string[] zeilen = File.ReadAllLines(pfad);
            Console.WriteLine("Highscores:");
            foreach (string zeile in zeilen)
            {
                Console.WriteLine(zeile);
            }
        }
    }
}
