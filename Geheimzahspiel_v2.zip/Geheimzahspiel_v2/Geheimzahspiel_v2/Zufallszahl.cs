﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geheimzahspiel_v2
{
    using System;

    class ZufallszahlGenerator
    {
        private Random zufallszahl = new Random();

        public int Zufallszahl(int min, int max)
        {
            return zufallszahl.Next(min, max + 1);
        }
    }

}
