﻿using Geheimzahspiel_v2;

class Program
{
    static void Main(string[] args)
    {
        Spiel spiel = new Spiel();
        spiel.Start();
    }
}